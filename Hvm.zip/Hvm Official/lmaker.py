# license_generator.py
import json
import base64
import datetime
import random
import string
import sys
import os
from ecdsa import SigningKey, VerifyingKey, NIST384p, BadSignatureError

class LicenseGenerator:
    def __init__(self, private_key_hex=None):
        """Initialize with private key."""
        if private_key_hex:
            self.private_key = SigningKey.from_string(
                bytes.fromhex(private_key_hex),
                curve=NIST384p
            )
            self.public_key = self.private_key.verifying_key
        else:
            self.private_key = None
            self.public_key = None
    
    def set_private_key(self, private_key_hex):
        """Set private key after initialization."""
        self.private_key = SigningKey.from_string(
            bytes.fromhex(private_key_hex),
            curve=NIST384p
        )
        self.public_key = self.private_key.verifying_key
    
    def generate_license(self, days=30, machine_id=None, 
                        license_type="standard", metadata=None):
        """
        Generate a signed license key.
        
        Args:
            days: License validity in days
            machine_id: Specific machine ID or None for any
            license_type: "trial", "standard", "lifetime"
            metadata: Additional metadata dict
        
        Returns:
            dict with license info
        """
        if not self.private_key:
            raise ValueError("Private key not set. Use set_private_key() first.")
        
        # Calculate expiration
        created = datetime.datetime.now()
        
        if license_type == "lifetime":
            expires = created + datetime.timedelta(days=36525)  # ~100 years
        elif license_type == "trial":
            expires = created + datetime.timedelta(days=min(days, 14))
        else:  # standard
            expires = created + datetime.timedelta(days=days)
        
        # Generate license ID
        license_id = f"{license_type[:3].upper()}-{''.join(random.choices(string.ascii_uppercase + string.digits, k=8))}"
        
        # Prepare license data
        license_data = {
            'id': license_id,
            'created': created.isoformat(),
            'expires': expires.isoformat(),
            'machine_id': machine_id,
            'type': license_type,
            'version': '4.0',
            'validity_days': days if license_type != 'lifetime' else 36525,
            'metadata': metadata or {}
        }
        
        # Sign and encode
        data_json = json.dumps(license_data, sort_keys=True)
        data_bytes = data_json.encode('utf-8')
        signature = self.private_key.sign(data_bytes)
        combined = data_bytes + b'||' + signature
        license_key = base64.b64encode(combined).decode('utf-8')
        
        return {
            'license_key': license_key,
            'license_data': license_data,
            'license_id': license_id,
            'created': created.isoformat(),
            'expires': expires.isoformat(),
            'validity_days': days if license_type != 'lifetime' else 36525,
            'type': license_type,
            'machine_id': machine_id
        }
    
    def validate_license(self, license_key):
        """Validate a license key using the public key."""
        if not self.public_key:
            raise ValueError("Public key not available.")
        
        try:
            decoded = base64.b64decode(license_key)
            data_b, sign = decoded.rsplit(b'||', 1)
            data = data_b.decode('utf-8')
            
            self.public_key.verify(sign, data_b)
            license_data = json.loads(data)
            
            expired = datetime.datetime.fromisoformat(license_data['expires']) < datetime.datetime.now()
            
            return {
                'valid': True,
                'signature_valid': True,
                'expired': expired,
                'license_data': license_data
            }
        except BadSignatureError:
            return {'valid': False, 'error': 'Invalid signature'}
        except Exception as e:
            return {'valid': False, 'error': str(e)}
    
    def batch_generate(self, count=1, days=30, machine_ids=None, 
                      license_type="standard"):
        """Generate multiple licenses."""
        licenses = []
        for i in range(count):
            machine_id = machine_ids[i] if machine_ids and i < len(machine_ids) else None
            license_result = self.generate_license(
                days=days,
                machine_id=machine_id,
                license_type=license_type
            )
            licenses.append(license_result)
        return licenses


def load_private_key_from_file(filename="private_key.txt"):
    """Load private key from a file."""
    try:
        with open(filename, 'r') as f:
            content = f.read()
        
        # Look for private key in various formats
        import re
        patterns = [
            r"PRIVATE_KEY\s*=\s*'([a-fA-F0-9]+)'",
            r'"([a-fA-F0-9]{96,})"',  # ECDSA NIST384p key is 96 bytes hex
            r"'([a-fA-F0-9]{96,})'",
            r"([a-fA-F0-9]{96,})"  # Just the hex
        ]
        
        for pattern in patterns:
            match = re.search(pattern, content)
            if match:
                return match.group(1)
        
        return None
    except FileNotFoundError:
        return None
    except Exception as e:
        print(f"Error reading key file: {e}")
        return None


def print_license_result(result, show_key=True):
    """Print license information nicely."""
    print("\n" + "=" * 60)
    print("✅ LICENSE GENERATED SUCCESSFULLY")
    print("=" * 60)
    
    print(f"License ID: {result.get('license_id', 'N/A')}")
    print(f"Type: {result.get('type', 'standard').upper()}")
    print(f"Created: {result.get('created', 'N/A')}")
    print(f"Expires: {result.get('expires', 'N/A')}")
    print(f"Validity: {result.get('validity_days', 0)} days")
    
    machine_id = result.get('machine_id')
    if machine_id:
        print(f"Machine ID: {machine_id}")
    else:
        print("Machine ID: Any (unrestricted)")
    
    if show_key:
        print("\n" + "-" * 60)
        print("LICENSE KEY:")
        print("-" * 60)
        print(result['license_key'])
        print("-" * 60)


def save_license_to_file(result, filename=None):
    """Save license to a file."""
    if not filename:
        filename = f"license_{result.get('license_id', 'unknown')}.txt"
    
    try:
        with open(filename, 'w') as f:
            f.write(f"HVM PANEL LICENSE\n")
            f.write(f"{'=' * 50}\n\n")
            f.write(f"License ID: {result.get('license_id', 'N/A')}\n")
            f.write(f"Type: {result.get('type', 'standard')}\n")
            f.write(f"Created: {result.get('created', 'N/A')}\n")
            f.write(f"Expires: {result.get('expires', 'N/A')}\n")
            f.write(f"Validity: {result.get('validity_days', 0)} days\n")
            
            machine_id = result.get('machine_id')
            if machine_id:
                f.write(f"Machine ID: {machine_id}\n")
            else:
                f.write("Machine ID: Any (unrestricted)\n")
            
            f.write(f"\n{'=' * 50}\n")
            f.write("LICENSE KEY:\n")
            f.write(f"{'=' * 50}\n")
            f.write(f"{result['license_key']}\n")
        
        return filename
    except Exception as e:
        print(f"Error saving file: {e}")
        return None


def interactive_generator():
    """Interactive CLI license generator."""
    
    print("\n" + "=" * 60)
    print("🎫 HVM PANEL LICENSE GENERATOR")
    print("=" * 60)
    
    # Try to load private key automatically
    private_key = None
    print("\n🔑 Loading private key...")
    
    # Check for command line argument
    if len(sys.argv) > 1:
        private_key = sys.argv[1]
        print("✓ Using private key from command line")
    else:
        # Try to load from common locations
        possible_files = ["private_key.txt", "hvm_private.key", "key.txt"]
        for filename in possible_files:
            if os.path.exists(filename):
                private_key = load_private_key_from_file(filename)
                if private_key:
                    print(f"✓ Loaded private key from {filename}")
                    break
        
        if not private_key:
            print("⚠️  No private key file found.")
            print("   Place your private key in private_key.txt or enter it manually.")
    
    # If still no key, ask user
    if not private_key:
        key_source = input("\nEnter private key or path to key file: ").strip()
        
        if os.path.exists(key_source):
            private_key = load_private_key_from_file(key_source)
            if not private_key:
                print("❌ Could not read key from file.")
                return
        else:
            # Assume it's the key itself
            if len(key_source) == 96:  # ECDSA NIST384p key length in hex
                private_key = key_source
                print("✓ Using provided private key")
            else:
                print("❌ Invalid key format. Expected 96-character hex string.")
                return
    
    # Initialize generator
    try:
        generator = LicenseGenerator(private_key)
        print("✓ License generator initialized")
    except Exception as e:
        print(f"❌ Error initializing generator: {e}")
        return
    
    while True:
        print("\n" + "-" * 60)
        print("MAIN MENU")
        print("-" * 60)
        print("1. Generate Single License")
        print("2. Generate Trial License")
        print("3. Generate Lifetime License")
        print("4. Batch Generate Licenses")
        print("5. Validate Existing License")
        print("6. Change Private Key")
        print("7. Exit")
        print("-" * 60)
        
        choice = input("\nSelect option (1-7): ").strip()
        
        if choice == '1':
            print("\n--- Generate Standard License ---")
            try:
                days = int(input("Validity days (default 30): ") or "30")
                machine_id = input("Machine ID (hex, leave empty for any): ").strip()
                if not machine_id:
                    machine_id = None
                
                license_type = "standard"
                if days > 365:
                    confirm = input(f"⚠️  {days} days is a long time. Confirm? (y/n): ")
                    if confirm.lower() != 'y':
                        continue
                
                print("\nGenerating license...")
                result = generator.generate_license(
                    days=days,
                    machine_id=machine_id,
                    license_type=license_type
                )
                
                print_license_result(result)
                
                save = input("\n💾 Save to file? (y/n): ").lower()
                if save == 'y':
                    filename = save_license_to_file(result)
                    if filename:
                        print(f"✅ License saved to {filename}")
            
            except ValueError:
                print("❌ Invalid input. Please enter numbers.")
            except Exception as e:
                print(f"❌ Error generating license: {e}")
        
        elif choice == '2':
            print("\n--- Generate Trial License ---")
            try:
                days = int(input("Trial days (1-14, default 7): ") or "7")
                days = max(1, min(days, 14))  # Limit trial to 14 days
                
                machine_id = input("Machine ID (hex, leave empty for any): ").strip()
                if not machine_id:
                    machine_id = None
                
                print("\nGenerating trial license...")
                result = generator.generate_license(
                    days=days,
                    machine_id=machine_id,
                    license_type="trial",
                    metadata={"notes": "Trial license", "restricted": True}
                )
                
                print_license_result(result)
                
                save = input("\n💾 Save to file? (y/n): ").lower()
                if save == 'y':
                    filename = save_license_to_file(result)
                    if filename:
                        print(f"✅ License saved to {filename}")
            
            except ValueError:
                print("❌ Invalid input.")
            except Exception as e:
                print(f"❌ Error generating license: {e}")
        
        elif choice == '3':
            print("\n--- Generate Lifetime License ---")
            try:
                machine_id = input("Machine ID (hex, leave empty for any): ").strip()
                if not machine_id:
                    machine_id = None
                
                confirm = input("⚠️  Generate LIFETIME license? (type 'LIFETIME' to confirm): ")
                if confirm.upper() != 'LIFETIME':
                    print("Lifetime license generation cancelled.")
                    continue
                
                print("\nGenerating lifetime license...")
                result = generator.generate_license(
                    days=0,  # Not used for lifetime
                    machine_id=machine_id,
                    license_type="lifetime",
                    metadata={"notes": "Lifetime license", "premium": True}
                )
                
                print_license_result(result)
                
                save = input("\n💾 Save to file? (y/n): ").lower()
                if save == 'y':
                    filename = save_license_to_file(result)
                    if filename:
                        print(f"✅ License saved to {filename}")
            
            except Exception as e:
                print(f"❌ Error generating license: {e}")
        
        elif choice == '4':
            print("\n--- Batch Generate Licenses ---")
            try:
                count = int(input("Number of licenses to generate: "))
                days = int(input("Validity days for each: "))
                license_type = input("License type (standard/trial): ").lower()
                
                if license_type not in ["standard", "trial"]:
                    license_type = "standard"
                
                machine_ids = []
                use_same_machine = input("Same machine ID for all? (y/n): ").lower()
                
                if use_same_machine == 'y':
                    machine_id = input("Machine ID for all (leave empty for any): ").strip()
                    machine_ids = [machine_id if machine_id else None] * count
                else:
                    print(f"Enter machine ID for each license (leave empty for any):")
                    for i in range(count):
                        mid = input(f"License {i+1}: ").strip()
                        machine_ids.append(mid if mid else None)
                
                print(f"\nGenerating {count} licenses...")
                licenses = generator.batch_generate(
                    count=count,
                    days=days,
                    machine_ids=machine_ids,
                    license_type=license_type
                )
                
                print(f"\n✅ Generated {len(licenses)} licenses")
                
                # Show summary
                for i, license_result in enumerate(licenses):
                    print(f"\n{i+1}. {license_result['license_id']} - Expires: {license_result['expires']}")
                
                save_all = input("\n💾 Save all to files? (y/n): ").lower()
                if save_all == 'y':
                    saved_count = 0
                    for i, license_result in enumerate(licenses):
                        filename = f"license_{license_result['license_id']}.txt"
                        if save_license_to_file(license_result, filename):
                            saved_count += 1
                    print(f"✅ Saved {saved_count} licenses to files")
                
                save_csv = input("\n💾 Export to CSV file? (y/n): ").lower()
                if save_csv == 'y':
                    try:
                        csv_filename = f"licenses_batch_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                        with open(csv_filename, 'w') as f:
                            f.write("License ID,Type,Expires,Machine ID,License Key\n")
                            for license_result in licenses:
                                f.write(f"{license_result['license_id']},{license_result['type']},{license_result['expires']},{license_result.get('machine_id', 'Any')},{license_result['license_key']}\n")
                        print(f"✅ Exported to {csv_filename}")
                    except Exception as e:
                        print(f"❌ Error exporting CSV: {e}")
            
            except ValueError:
                print("❌ Invalid input.")
            except Exception as e:
                print(f"❌ Error generating licenses: {e}")
        
        elif choice == '5':
            print("\n--- Validate License ---")
            license_key = input("Enter license key to validate: ").strip()
            if license_key:
                print("\nValidating...")
                result = generator.validate_license(license_key)
                
                if result['valid']:
                    print("✅ License is VALID")
                    data = result['license_data']
                    print(f"   ID: {data.get('id', 'N/A')}")
                    print(f"   Type: {data.get('type', 'standard')}")
                    print(f"   Expires: {data.get('expires', 'N/A')}")
                    
                    if result.get('expired'):
                        print("   ⚠️  License has EXPIRED")
                    else:
                        print("   ✓ License is ACTIVE")
                    
                    if data.get('machine_id'):
                        print(f"   Machine ID: {data['machine_id']}")
                    else:
                        print("   Machine ID: Any")
                else:
                    print(f"❌ License is INVALID")
                    print(f"   Error: {result.get('error', 'Unknown error')}")
            else:
                print("❌ No license key provided.")
        
        elif choice == '6':
            print("\n--- Change Private Key ---")
            new_key = input("Enter new private key or path to key file: ").strip()
            
            if os.path.exists(new_key):
                loaded_key = load_private_key_from_file(new_key)
                if loaded_key:
                    generator.set_private_key(loaded_key)
                    print("✓ Private key updated from file")
                else:
                    print("❌ Could not read key from file.")
            else:
                if len(new_key) == 96:
                    generator.set_private_key(new_key)
                    print("✓ Private key updated")
                else:
                    print("❌ Invalid key format. Expected 96-character hex string.")
        
        elif choice == '7':
            print("\n👋 Goodbye!")
            break
        
        else:
            print("❌ Invalid choice. Please select 1-7.")
        
        # Ask to continue
        continue_choice = input("\n↩️  Return to main menu? (y/n): ").lower()
        if continue_choice != 'y':
            print("\n👋 Goodbye!")
            break


if __name__ == "__main__":
    # Check for command line mode
    if len(sys.argv) > 2 and sys.argv[1] == "--generate":
        # Quick command line generation
        try:
            private_key = sys.argv[2]
            days = int(sys.argv[3]) if len(sys.argv) > 3 else 30
            machine_id = sys.argv[4] if len(sys.argv) > 4 else None
            
            generator = LicenseGenerator(private_key)
            result = generator.generate_license(days=days, machine_id=machine_id)
            
            print(result['license_key'])
            if len(sys.argv) > 5 and sys.argv[5] == "--verbose":
                print(f"\nLicense ID: {result['license_id']}")
                print(f"Expires: {result['expires']}")
        
        except Exception as e:
            print(f"Error: {e}")
            print("Usage: python license_generator.py --generate <private_key> [days] [machine_id] [--verbose]")
    
    elif len(sys.argv) > 1 and sys.argv[1] == "--validate":
        # Command line validation
        try:
            private_key = sys.argv[2]
            license_key = sys.argv[3]
            
            generator = LicenseGenerator(private_key)
            result = generator.validate_license(license_key)
            
            if result['valid']:
                print("VALID")
                data = result['license_data']
                print(f"ID: {data.get('id')}")
                print(f"Expires: {data.get('expires')}")
                print(f"Expired: {result.get('expired', False)}")
            else:
                print("INVALID")
                print(f"Error: {result.get('error')}")
        
        except Exception as e:
            print(f"Error: {e}")
            print("Usage: python license_generator.py --validate <private_key> <license_key>")
    
    else:
        # Run interactive mode
        interactive_generator()
