# update_keys.py
import sys
import re
from ecdsa import SigningKey, VerifyingKey, NIST384p

def generate_and_update_keys():
    """Generate new key pair and update hvm.py automatically."""
    
    print("\n" + "=" * 60)
    print("🔐 HVM PANEL KEY UPDATER")
    print("=" * 60)
    
    # Generate new key pair
    print("\n🔄 Generating new ECDSA key pair...")
    private_key = SigningKey.generate(curve=NIST384p)
    public_key = private_key.verifying_key
    
    private_hex = private_key.to_string().hex()
    public_hex = public_key.to_string().hex()
    
    print("✅ Keys generated successfully!")
    
    # Display keys
    print("\n" + "-" * 60)
    print("PRIVATE KEY (SAVE THIS FOR LICENSE GENERATION):")
    print("-" * 60)
    print(private_hex)
    print("-" * 60)
    
    print("\n" + "-" * 60)
    print("PUBLIC KEY (will be updated in hvm.py):")
    print("-" * 60)
    print(public_hex)
    print("-" * 60)
    
    # Read hvm.py
    try:
        with open('hvm.py', 'r') as f:
            content = f.read()
        
        # Update PUBLIC_HEX in hvm.py
        old_public_match = re.search(r"PUBLIC_HEX = '([a-fA-F0-9]+)'", content)
        
        if old_public_match:
            old_public = old_public_match.group(1)
            new_content = content.replace(old_public, public_hex)
            
            # Write updated file
            with open('hvm.py', 'w') as f:
                f.write(new_content)
            
            print(f"\n✅ Updated hvm.py")
            print(f"   Old public key: ...{old_public[-20:]}")
            print(f"   New public key: ...{public_hex[-20:]}")
        else:
            print("\n⚠️  Could not find PUBLIC_HEX in hvm.py")
            print(f"   Manually update with: PUBLIC_HEX = '{public_hex}'")
    
    except FileNotFoundError:
        print("\n❌ hvm.py not found in current directory!")
        print(f"   Manual update required: PUBLIC_HEX = '{public_hex}'")
    except Exception as e:
        print(f"\n❌ Error updating file: {e}")
        print(f"   Manual update required: PUBLIC_HEX = '{public_hex}'")
    
    # Save private key to secure file
    save_private = input("\n💾 Save private key to file? (y/n): ").lower()
    if save_private == 'y':
        filename = input("Enter filename (default: private_key.txt): ") or "private_key.txt"
        try:
            with open(filename, 'w') as f:
                f.write(f"# HVM PANEL PRIVATE KEY - KEEP SECURE!\n")
                f.write(f"# Generated: {__import__('datetime').datetime.now()}\n")
                f.write(f"# For use with license_generator.py\n")
                f.write(f"\nPRIVATE_KEY = '{private_hex}'\n")
            print(f"✅ Private key saved to {filename}")
            print("   ⚠️  Keep this file secure and backup!")
        except Exception as e:
            print(f"❌ Error saving file: {e}")
    
    # Create a summary
    print("\n" + "=" * 60)
    print("📋 KEY UPDATE SUMMARY")
    print("=" * 60)
    print("✅ New keys generated")
    print("✅ hvm.py updated with new public key")
    if save_private == 'y':
        print(f"✅ Private key saved to file")
    
    print("\n📝 NEXT STEPS:")
    print("1. Restart your HVM panel to use new keys")
    print("2. Use license_generator.py with your private key")
    print("3. Generate new licenses for all users")
    print("4. Old licenses will no longer be valid")
    
    print("\n🔑 Your Private Key (copy this):")
    print("-" * 60)
    print(private_hex)
    print("-" * 60)
    
    return private_hex, public_hex

def backup_old_keys():
    """Optional: Backup old keys if you want to keep them."""
    try:
        with open('hvm.py', 'r') as f:
            content = f.read()
        
        old_match = re.search(r"PUBLIC_HEX = '([a-fA-F0-9]+)'", content)
        if old_match:
            old_public = old_match.group(1)
            with open('old_key_backup.txt', 'a') as f:
                f.write(f"Old public key (replaced): {old_public}\n")
                f.write(f"Date replaced: {__import__('datetime').datetime.now()}\n\n")
            print(f"\n📦 Old public key backed up to old_key_backup.txt")
    
    except Exception as e:
        pass  # Silently fail if backup fails

if __name__ == "__main__":
    print("\n⚠️  WARNING: This will generate NEW encryption keys.")
    print("All existing licenses will become invalid!")
    print("You'll need to generate new licenses for all users.")
    
    confirm = input("\nAre you sure you want to proceed? (type 'YES' to continue): ")
    
    if confirm.upper() == 'YES':
        backup_old_keys()
        private_key, public_key = generate_and_update_keys()
        
        # Ask about generating test license
        test = input("\n🎫 Generate a test license with new keys? (y/n): ").lower()
        if test == 'y':
            print("\nOpening license generator...")
            # Import and run generator
            try:
                import subprocess
                # Create a temporary script to generate test license
                temp_script = f'''
import json, base64, datetime, random, string
from ecdsa import SigningKey, NIST384p

private_key = SigningKey.from_string(bytes.fromhex("{private_key}"), curve=NIST384p)

created = datetime.datetime.now()
expires = created + datetime.timedelta(days=30)
license_id = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))

license_data = {{
    'id': license_id,
    'created': created.isoformat(),
    'expires': expires.isoformat(),
    'machine_id': None,
    'version': '4.0',
    'type': 'test'
}}

data_json = json.dumps(license_data, sort_keys=True)
data_bytes = data_json.encode('utf-8')
signature = private_key.sign(data_bytes)
combined = data_bytes + b'||' + signature
license_key = base64.b64encode(combined).decode('utf-8')

print("\\n✅ TEST LICENSE GENERATED")
print("=" * 50)
print(f"License ID: {{license_id}}")
print(f"Expires: {{expires}}")
print("\\nLicense Key:")
print("=" * 50)
print(license_key)
print("=" * 50)
'''
                
                with open('_test_gen.py', 'w') as f:
                    f.write(temp_script)
                
                subprocess.run([sys.executable, '_test_gen.py'])
                import os
                os.remove('_test_gen.py')
                
            except Exception as e:
                print(f"Could not generate test license: {e}")
    else:
        print("\nOperation cancelled.")
